"""Authenticated ERP ↔ ABIT.AI Agentic Governance API v1.

ERP owns Project/Task and AI User identities. ABIT.AI owns per-project
Automations and durable agent-to-agent invocations. ERP changes use fixed native
RPCs and receiving permission guards; no direct SAP writes.
"""

from __future__ import annotations

import asyncio
import hmac
import json
import logging
import os
import time
from pathlib import Path
from typing import Literal

from fastapi import APIRouter, Header, HTTPException, Request, WebSocket
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, ConfigDict

from open_webui.env import DATA_DIR
from open_webui.models.users import Users
from open_webui.utils.agentic_governance import (
    HANDOFFS,
    PROJECT_ID,
    ROLES,
    TASK_ID,
    RECONCILE_SECONDS,
    registered_agent_id,
    enqueue,
    find,
    list_invocations,
    recoverable,
    roster,
    transition,
)
from open_webui.utils.automations import execute_automation
from open_webui.utils.agentic_project_policy import (
    REQUIRED_PROJECT_MANAGER,
    project_status_allowed,
    project_eligibility_reason,
)

log = logging.getLogger(__name__)
router = APIRouter()

DEFAULT_ROLE_USERS = {
    "solution_architect": "ai-projects@abitcons.com",
    "project_manager": "ai-projects@abitcons.com",
    "developer": "ai-developer@abitcons.com",
    "qa": "ai-qa@abitcons.com",
    "operations": "ai-operations@abitcons.com",
    "it_manager": "ai-operations@abitcons.com",
}

ROLE_TITLES = {
    "solution_architect": "Solution Architect",
    "project_manager": "Project Manager",
    "developer": "AI Developer",
    "qa": "Independent QA",
    "operations": "Operations",
    "it_manager": "IT Manager",
}

ROLE_NOTES = {
    "solution_architect": (
        "Decompose the ERP Project SRS by algorithmic input, action, output and verification; "
        "produce inspectable UML and UI mockup artifacts, propose deduplicated ERP subtasks and "
        "acceptance tests via approved APIs. Never claim mockups were produced without files."
    ),
    "project_manager": (
        "Own the dependency-ordered project task tree; check active agents, leases and evidence "
        "before assigning. Send scoped requests to developers, operations, QA or IT via ABIT.AI API. "
        "Never mark a business task complete without independent verification."
    ),
    "developer": (
        "Verify authoritative repository, branch, instructions and existing work before editing. "
        "Implement safely, test and record exact evidence. Ask QA through authenticated agent API "
        "when a deliverable is ready. Never deploy to production without required approval."
    ),
    "qa": (
        "Independently test the required acceptance criteria, including security, regression and "
        "UI where relevant. Report reproducible defects with evidence and return work for correction. "
        "Do not approve your own implementation."
    ),
    "operations": (
        "Execute routine project operations using authorized systems of record. Verify permissions, "
        "task scope, outcomes and customer impact. Request IT/QA follow-ups through governed APIs."
    ),
    "it_manager": (
        "Inspect the exact authorized host, system, backups, log retention, service impact and "
        "recovery path before IT work. Official package installations and reversible disposal of "
        "identified temporary files may be permitted; preserve active/audit/security logs, "
        "database WAL, backups and business data. Require approval for risky production, "
        "destructive, sensitive security or material service-impacting actions."
    ),
}


class ProvisionInput(BaseModel):
    model_id: Literal["abitdot"] = "abitdot"


class AgentLink(BaseModel):
    role: Literal['solution_architect', 'project_manager', 'developer', 'qa', 'operations', 'it_manager']
    agent_id: str = Field(min_length=36, max_length=36)
    erp_user: str = Field(min_length=3, max_length=254)
    agent_url: str = Field(pattern=r'^https://abit\.ai/automations/[A-Za-z0-9-]{36}$')


class ProvisionResponse(BaseModel):
    project: str
    agents: list[AgentLink] = Field(min_length=6, max_length=6)
    trigger: Literal['api_only']
    polling: Literal['30-minute_reconciliation_fallback']


class AgentDiscoveryResponse(BaseModel):
    project: str
    agents: list[AgentLink] = Field(max_length=6)


class InvocationReceipt(BaseModel):
    invocation_id: str
    state: str
    created: bool
    project: str
    target_role: Literal['solution_architect', 'project_manager', 'developer', 'qa', 'operations', 'it_manager']


class InvocationHistoryResponse(BaseModel):
    project: str
    runs: list[dict] = Field(max_length=100)


class InvocationInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    invocation_id: str = Field(min_length=16, max_length=160, pattern=r'^[A-Za-z0-9_.:@+-]+$')
    erp_task_id: str = Field(pattern=r'^TASK-[A-Za-z0-9-]{1,60}$')
    from_role: Literal['erp', 'solution_architect', 'project_manager', 'developer', 'qa', 'operations', 'it_manager']
    target_role: Literal['solution_architect', 'project_manager', 'developer', 'qa', 'operations', 'it_manager']
    task_revision: str = Field(min_length=1, max_length=100)
    context: str = Field(min_length=1, max_length=50000)
    from_agent_id: str | None = None
    source_invocation_id: str | None = None


def _auth(control_secret: str) -> None:
    # Reuse the already-deployed, server-to-server ERP Task control credential.
    # Do not issue API tokens to models or browsers; calls originate in trusted
    # ABIT.AI tools/ERP server-side proxy with an approved scoped identity.
    if not control_secret or len(control_secret) < 32:
        raise HTTPException(401, "Invalid ERP Agentic Governance credential")
    secret_file = Path(
        os.getenv(
            "ABIT_ERP_CONTROL_TOKEN_FILE",
            str(Path(DATA_DIR).parent / "config/erp-assignment/control-token"),
        )
    )
    try:
        expected = secret_file.read_text().strip()
    except OSError:
        raise HTTPException(503, "ERP Agentic Governance credential unavailable") from None
    if len(expected) < 32 or not control_secret or not hmac.compare_digest(control_secret, expected):
        raise HTTPException(401, "Invalid ERP Agentic Governance credential")


def _config() -> dict:
    cfgpath = os.getenv('ABIT_ERP_TASK_RESOLUTION_CONFIG')
    if not cfgpath:
        raise HTTPException(503, "ERP task integration not configured")
    try:
        return json.loads(Path(cfgpath).read_text())
    except (OSError, ValueError):
        raise HTTPException(503, "ERP task configuration unavailable") from None


class GatewayProofInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    protocol_version: Literal[1]
    scope: dict
    scope_digest: str = Field(pattern=r'^[a-f0-9]{64}$')


class GatewayAdmissionInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    protocol_version: Literal[1]
    scope: dict
    preflight_proof: dict
    submission_proof: dict


async def _gateway_controller(operation, body):
    from open_webui.utils.agentic_bridge import ERPBridge, digest
    from open_webui.utils import agentic_gateway_sessions as gateway
    from open_webui.utils.agentic_gateway_operations import registry
    from open_webui.utils.agentic_tool_gateway import CapabilityUnavailable

    config = _config()
    value = body.model_dump()
    if operation == 'receipt':
        try:
            return gateway.original_receipt(value)
        except ValueError:
            raise HTTPException(409, 'Exact original gateway admission receipt is unavailable') from None
    if operation == 'proof' and value['scope_digest'] != digest(value['scope']):
        raise HTTPException(409, 'Gateway scope fingerprint does not match')
    bridge = ERPBridge(config)
    try:
        operations = registry(value['scope'].get('role'))
        kwargs = dict(bridge=bridge, project_gate=_gate, config=config, registry=operations)
        if operation == 'proof':
            return await gateway.proof(value['scope'], **kwargs)
        return await gateway.admit(value, **kwargs)
    except CapabilityUnavailable as error:
        if operation == 'proof':
            from open_webui.utils.agentic_relay_scope import gateway_proof_failure_detail

            raise HTTPException(424, gateway_proof_failure_detail(error)) from None
        raise HTTPException(424, str(error)) from None
    except HTTPException:
        raise
    except Exception as error:
        if operation == 'proof':
            from open_webui.utils.agentic_relay_scope import gateway_proof_failure_detail

            raise HTTPException(409, gateway_proof_failure_detail(error)) from None
        raise HTTPException(409, _erp_failure(error, 'Gateway authority validation failed')) from None
    finally:
        await bridge.close()


@router.post('/gateway/proof', tags=['Agentic scoped gateway'])
async def gateway_proof(body: GatewayProofInput, x_abit_erp_control: str = Header(default='')):
    """Negotiate read-only scope without admission or provider execution.

    Failed checks return fixed diagnostic codes without upstream response,
    packet or credential contents; all existing authority checks still apply.
    """
    _auth(x_abit_erp_control)
    return await _gateway_controller('proof', body)


@router.post('/gateway/admit', tags=['Agentic scoped gateway'])
async def gateway_admit(body: GatewayAdmissionInput, x_abit_erp_control: str = Header(default='')):
    _auth(x_abit_erp_control)
    return await _gateway_controller('admit', body)


@router.post('/gateway/receipt', tags=['Agentic scoped gateway'])
async def gateway_receipt(body: GatewayAdmissionInput, x_abit_erp_control: str = Header(default='')):
    _auth(x_abit_erp_control)
    return await _gateway_controller('receipt', body)


@router.websocket('/erp-channel')
async def erp_private_channel(websocket: WebSocket):
    from open_webui.utils.agentic_erp_runtime import configured_channel

    try:
        channel = configured_channel()
    except Exception:
        await websocket.close(code=1011)
        return
    if channel is None:
        await websocket.close(code=4403)
        return
    await channel.endpoint(websocket, on_ready=lambda: _reconciliation_wakeup(websocket.app).set())


@router.get('/erp-channel/status', tags=['Agentic scoped gateway'])
async def erp_private_channel_status(x_abit_erp_control: str = Header(default='')):
    _auth(x_abit_erp_control)
    from open_webui.utils.agentic_erp_runtime import configured_channel

    channel = configured_channel()
    return channel.status() if channel is not None else {'enabled': False, 'connected': False, 'inflight': 0}


@router.post('/gateway/call', tags=['Agentic scoped gateway'])
async def gateway_call(request: Request):
    """Execute one admitted role operation and retain its original call identity.

    Long repository.test calls return an uncertain receipt within 20 seconds
    while the single retained original job continues. Repeat its exact session,
    call_id, operation and arguments to read its receipt without another test.
    Infrastructure request parameters omit credentials, authority identities,
    commands and URLs; the server derives identity from the immutable packet.

    The authenticated edge envelope carries the admitted session, capability,
    operation, arguments and stable call_id. repository.read supports bounded byte
    paging; Developer repository.patch uses exact UTF-8 edits and complete prior SHA256.
    Operator test budgets keep scratch writes memory-backed and network-isolated.
    context.read reports safe repository
    registration readiness. Repository policy comes from the exact Project
    registration or one enabled server-approved repository/environment template;
    templates derive separate Project workspaces and grant no IT approval.
    Physical dependency verification requires a separate exact Project/SRS
    policy or its existing Project registration. Malformed or conflicting
    policy registrations are denied before a native dependency read.
    Missing or conflicting registrations return a useful prerequisite error.
    context.read also reports supported artifact extensions, byte limits and
    immutable filename rules. New artifact.write arguments are validated before
    conversation binding or a write intent. Existing receipts remain unchanged;
    failures after an intent retain uncertainty and never authorize replay.
    """
    from open_webui.utils import agentic_gateway_sessions as gateway
    from open_webui.utils.agentic_gateway_operations import registry
    from open_webui.utils.agentic_tool_gateway import CapabilityUnavailable
    from open_webui.utils.agentic_bridge import ERPBridge

    # Do not parse an unlimited body, or expose server credentials in errors.
    raw = bytearray()
    async for chunk in request.stream():
        raw.extend(chunk)
        if len(raw) > 300_000:
            raise HTTPException(413, 'Gateway request exceeds its size limit')
    try:
        body = json.loads(raw)
        gateway.verify_edge(body, request.headers, gateway.edge_secret())
    except CapabilityUnavailable:
        raise HTTPException(503, 'Authenticated gateway edge is unavailable') from None
    except (ValueError, TypeError):
        raise HTTPException(401, 'Authenticated gateway edge envelope is required') from None
    config = _config()
    async def original_operation():
        bridge = ERPBridge(config)
        try:
            with gateway.connect() as db:
                row=db.execute('SELECT scope_json FROM governance_gateway_session WHERE session_id=?',
                               (body['session_id'],)).fetchone()
            if not row:
                raise HTTPException(403,'This gateway job capability has not been admitted')
            scope=json.loads(row['scope_json'])
            return await gateway.call(body,bridge=bridge,project_gate=_gate,config=config,
                                      registry=registry(scope['role']))
        except CapabilityUnavailable as error:
            raise HTTPException(424,str(error)) from None
        except HTTPException:
            raise
        except Exception as error:
            raise HTTPException(409,_erp_failure(error,'Gateway action rejected; reconcile original call before retry')) from None
        finally:
            await bridge.close()
    if body['operation']=='repository.test':
        # Retain ONE original job beyond the OAuth edge's 60-second request.
        # Repeated calls only read its immutable journal; they cannot rerun it.
        original=_spawn(request.app,original_operation())
        done,_=await asyncio.wait({original},timeout=20)
        if done:
            return original.result()
        return {'call_id':body['call_id'],'state':'uncertain','result':None,'replayed':False}
    return await original_operation()


def _erp_failure(error, context):
    from open_webui.utils.erp_status_write import ERPResponseError, ERPStateChanged

    if isinstance(error, (ERPResponseError, ERPStateChanged)):
        return context + ': ' + str(error)[:700]
    return context + ' (' + type(error).__name__ + ')'


async def _erp_project(project: str, config: dict) -> dict:
    """Re-verify Project hold status and open ai-projects assignment on EVERY entry."""
    from open_webui.utils.agentic_erp_runtime import governed_client as ERPClient
    from open_webui.utils.agentic_erp_channel import ERPReadUnavailable
    from open_webui.utils.agentic_preclaim_recovery import PreclaimERPUnavailable

    if not PROJECT_ID.fullmatch(project):
        raise HTTPException(400, "Invalid ERP Project ID")
    erp = ERPClient(config["erp_token_file"])
    try:
        item = await erp.get("Project", project)
        if not project_status_allowed(item, project_id=project):
            raise HTTPException(409, "ERP Project is on hold, closed, or not active")
        # Preserve legacy pilot opt-in, but NEVER bypass the assignment gate.
        if item.get("custom_agentic_governance_enabled") not in (1, True, "1"):
            raise HTTPException(403, "ERP Project is not opted into Agentic Governance")
        if item.get('custom_ai_project_manager_task_automation_enabled') not in (1, True, '1'):
            raise HTTPException(403, 'ERP Project AI Project Manager Task Automation checkbox is disabled')
        assignment = await erp.request(
            "GET",
            "/api/method/frappe.client.get_value",
            params={
                "doctype": "Project",
                "filters": project,
                "fieldname": "_assign",
            },
        )
        payload = assignment.get("message") or {}
        # Both live records must agree: an open ToDo alone or stale _assign
        # alone must not authorize any model execution or new agent provision.
        todos = [
            row
            async for row in erp.rows(
                "ToDo",
                ["name", "allocated_to", "reference_type", "reference_name", "status"],
                [
                    ["reference_type", "=", "Project"],
                    ["reference_name", "=", project],
                    ["allocated_to", "=", REQUIRED_PROJECT_MANAGER],
                    ["status", "=", "Open"],
                ],
            )
        ]
        reason = project_eligibility_reason(
            item,
            payload.get("_assign"),
            todos,
            project_id=project,
        )
        if reason:
            raise HTTPException(403, reason)
        return item
    except HTTPException:
        raise
    except ERPReadUnavailable as error:
        raise PreclaimERPUnavailable(error) from None
    except Exception as error:
        raise HTTPException(
            503, _erp_failure(error, "ERP Project status or assignment could not be verified")
        ) from None
    finally:
        await erp.client.aclose()


async def _erp_task(project: str, task_id: str, revision: str, config: dict, target_role: str = "developer") -> dict:
    from open_webui.utils.agentic_erp_runtime import governed_client as ERPClient

    if not TASK_ID.fullmatch(task_id):
        raise HTTPException(400, "Invalid ERP Task ID")
    erp = ERPClient(config["erp_token_file"])
    try:
        task = await erp.get("Task", task_id)
    except Exception as error:
        raise HTTPException(503, _erp_failure(error, "ERP Task could not be verified")) from None
    finally:
        await erp.client.aclose()
    if task.get("project") != project or task.get("is_group") or task.get("is_template"):
        raise HTTPException(403, "ERP Task scope mismatch")
    allowed = {"Pending Review", "QA Reviewing"} if target_role == "qa" else {"Open", "Overdue"}
    if task.get("status") not in allowed:
        raise HTTPException(409, "ERP Task is not eligible for this specialist role")
    if str(task.get("modified") or "") != revision:
        raise HTTPException(409, "ERP Task revision changed; refresh work packet")
    return task


async def _role_users(config: dict) -> dict[str, str]:
    from open_webui.utils.agentic_erp_runtime import governed_client as ERPClient

    # Read the same shared role users in every project. Do not create new ERP Users.
    mapping = dict(DEFAULT_ROLE_USERS)
    optional = config.get("agentic_role_users") or {}
    if isinstance(optional, dict):
        mapping.update({k: v for k, v in optional.items() if k in ROLES and isinstance(v, str)})
    erp = ERPClient(config["erp_token_file"])
    try:
        for email in set(mapping.values()):
            record = await erp.get("User", email)
            if record.get("name") != email or int(record.get("enabled") or 0) != 1:
                raise HTTPException(409, "ERP role user is not enabled")
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(503, _erp_failure(error, "ERP role user identities could not be verified")) from None
    finally:
        await erp.client.aclose()
    return mapping


def _prompt(project: dict, role: str, project_id: str) -> str:
    name = str(project.get("project_name") or project_id)[:180]
    instructions = str(project.get("custom_ai_developer_instructions") or "")[:12000]
    return (
        f"ABIT.AI GOVERNANCE AGENT: {ROLE_TITLES[role]} for ERPNext Project {project_id} ({name}).\n"
        "ERPNext https://erp.abit.ai is the authority for Project instructions, tasks, "
        "assignments, comments and approvals. Run only the authenticated scoped task passed "
        "by ABIT.AI governance. Existing instructions, security and approvals outrank model text.\n"
        f"ROLE POLICY: {ROLE_NOTES[role]}\n"
        f"ERP PROJECT AI INSTRUCTIONS:\n{instructions}\n"
        "Agent-to-agent handoffs must go through authenticated ABIT.AI governance APIs, "
        "not a chat-only assertion or recurring polling. A success response is not a "
        "verified business task completion."
    )


@router.get("/health")
async def health():
    # No credentials or names: safe public readiness check.
    return {
        "service": "ABiT Agentic Governance API",
        "version": 1,
        "status": "ready",
        "event_driven": True,
        "reconciliation_fallback_seconds": RECONCILE_SECONDS,
        "roles": list(ROLES),
    }


@router.post("/projects/{project_id}/provision", response_model=ProvisionResponse)
async def provision(
    project_id: str,
    body: ProvisionInput,
    control_secret: str = Header(default="", alias="X-ABIT-ERP-Control"),
):
    """Reuse verified project specialists before creating missing roles.

    Existing ERP bindings, Automation ownership and role identities must agree.
    Interrupted onboarding retains the same inactive pending specialists until
    all six ERP bindings are verified; retry reconciles those original IDs.
    """
    _auth(control_secret)
    return await _provision_project(project_id, body.model_id)


async def _provision_project(project_id, model_id="abitdot"):
    cfg = _config()
    project = await _erp_project(project_id, cfg)
    role_users = await _role_users(cfg)
    user = await Users.get_user_by_email(cfg.get("owner_email") or "")
    if not user or user.role != "admin":
        raise HTTPException(503, "Configured ABIT.AI governance owner is unavailable")
    from open_webui.utils.agentic_bridge import ERPBridge
    from open_webui.utils.agentic_governance import project_control
    from open_webui.utils.agentic_onboarding import provision as reconcile_specialists

    bridge = ERPBridge(cfg)
    try:
        records = await reconcile_specialists(
            project_id,
            user.id,
            role_users,
            cfg,
            model_id,
            title=ROLE_TITLES,
            prompt=_prompt,
            project_gate=_erp_project,
            bridge=bridge,
        )
    except HTTPException:
        raise
    except ValueError as error:
        raise HTTPException(409, str(error)) from None
    except Exception as error:
        raise HTTPException(
            503,
            _erp_failure(
                error,
                'Specialist reconciliation is incomplete; original pending identities are retained without starting execution.',
            ),
        ) from None
    finally:
        await bridge.close()
    if project_control(project_id)['state'] == 'disabled':
        project_control(project_id, 'enable', actor='erp', policy_revision=str(project['modified']))
    return {
        "project": project_id,
        "agents": [
            {
                "agent_id": r["agent_id"],
                "erp_user": r["erp_user"],
                "role": r["role"],
                "agent_url": "https://abit.ai/automations/" + r["agent_id"],
            }
            for r in records
        ],
        "trigger": "api_only",
        "polling": "30-minute_reconciliation_fallback",
    }


@router.get("/projects/{project_id}/agents", response_model=AgentDiscoveryResponse)
async def agents(
    project_id: str,
    control_secret: str = Header(default="", alias="X-ABIT-ERP-Control"),
):
    _auth(control_secret)
    records = roster(project_id)
    return {
        "project": project_id,
        "agents": [
            {
                "role": r["role"],
                "agent_id": r["agent_id"],
                "erp_user": r["erp_user"],
                "agent_url": "https://abit.ai/automations/" + r["agent_id"],
            }
            for r in records
        ],
    }


async def _gate(project_id, config):
    item = await _erp_project(project_id, config)
    return item, {
        'enabled': True,
        'pm_task_automation_enabled': True,
        'project_status': item['status'],
        'assigned_user': REQUIRED_PROJECT_MANAGER,
        'revision': str(item['modified']),
    }


def _background_failure(error):
    """Bounded server HTTP diagnostics; never serialize arbitrary exceptions."""
    if not isinstance(error, HTTPException):
        return type(error).__name__
    import re

    status = error.status_code if type(error.status_code) is int else 'unknown'
    detail = error.detail
    if isinstance(detail, dict):
        detail = detail.get('server_messages')
    if isinstance(detail, list):
        detail = '; '.join(value[:1000] for value in detail[:5] if isinstance(value, str))
    if not isinstance(detail, str):
        return f'HTTPException status={status} detail=[structured detail omitted]'
    detail = detail[:5000]
    if re.search(r"(?i)traceback|\b(?:headers?|cookies?|set-cookie|authorization)\b|\b(?:prompt|response_text|envelope_json|admission_json|scope_json)[\"']?\s*[:=]", detail):
        return f'HTTPException status={status} detail=[private or traceback detail omitted]'
    detail = re.sub(r'[\x00-\x1f\x7f]+', ' ', detail)
    detail = re.sub(
        r"""(?ix)\b(api[_ -]?key|access[_ -]?token|refresh[_ -]?token|client[_ -]?secret|session[_ -]?token|auth[_ -]?token|token|secret|password|passwd|capability[_ -]?(?:mac|token)|signature|mac)["']?\s*[:=]\s*(?:"[^"\n]*"|'[^'\n]*'|[^\s,;&]+)""",
        lambda match: match.group(1) + '=[REDACTED]', detail)
    detail = re.sub(r'(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+', 'Bearer [REDACTED]', detail)
    detail = re.sub(r'://[^/\s@]+@', '://[REDACTED]@', detail)
    return f'HTTPException status={status} detail={detail[:700]}'


def _spawn(app, coroutine):
    # Keep strong references and cancel observers explicitly during shutdown;
    # upstream receipts/leases remain fenced rather than being replayed.
    tasks = getattr(app.state, 'agentic_execution_tasks', None)
    if tasks is None:
        tasks = set()
        app.state.agentic_execution_tasks = tasks
    task = asyncio.create_task(coroutine)
    tasks.add(task)

    def completed(done):
        tasks.discard(done)
        if done.cancelled():
            return
        error = done.exception()
        if error is not None:
            log.error('Governance event remains pending for original recovery: %s', _background_failure(error))

    task.add_done_callback(completed)
    return task


async def _deliver(app, invocation_id: str, task=None, context=None):
    from open_webui.utils.agentic_executor import execute, DotAdapter
    from open_webui.utils.agentic_governance import find

    cfg = _config()
    row = find(invocation_id, include_private=True)
    if row and row['target_role'] == 'it_manager':
        from open_webui.utils.agentic_it_execution import ITAdapter

        from open_webui.utils.agentic_native_verification import selected_packet
        packet = row.get("work_packet")
        if isinstance(packet, str):
            packet = json.loads(packet)
        if selected_packet(packet or {}):
            from open_webui.utils.agentic_native_execution import NativeVerificationAdapter
            adapter = NativeVerificationAdapter(app, _gate, cfg)
        else:
            adapter = ITAdapter(app, _gate, cfg)
    else:
        adapter = DotAdapter(app)
    receipt = await execute(invocation_id, project_gate=_gate, config=cfg, adapter=adapter,
                            on_preclaim_deferred=lambda: _reconciliation_wakeup(app).set())
    if receipt:
        await _advance(app, invocation_id, receipt)


async def _advance(app, invocation_id, receipt):
    from open_webui.utils.agentic_orchestrator import advance

    async def dispatch(ident):
        _spawn(app, _deliver(app, ident))

    return await advance(invocation_id, receipt, config=_config(), project_gate=_gate, dispatch=dispatch)


@router.post("/projects/{project_id}/invoke", status_code=202, response_model=InvocationReceipt)
async def invoke(
    project_id: str,
    body: InvocationInput,
    request: Request,
    control_secret: str = Header(default="", alias="X-ABIT-ERP-Control"),
):
    """Invoke one versioned Project specialist under current ERP authorization.

    Architect dispatch includes exact plan metadata for its governance invocation,
    canonical ERP Project URL, SRS revision/hash and registered Project/role binding.
    The outer AutomationRun keeps its separate transport identity. Existing packet
    and result validation remains authoritative.
    """
    _auth(control_secret)
    cfg = _config()
    project, gate = await _gate(project_id, cfg)
    from open_webui.utils import agentic_governance as ledger
    from open_webui.utils.agentic_bridge import ERPBridge

    bridge = ERPBridge(cfg)
    try:
        packet = await bridge.packet(
            project_id, body.erp_task_id, body.target_role, registered_agent_id(project_id, body.target_role)
        )
        if body.task_revision not in {packet['task_revision'], packet.get('source_modified')}:
            raise HTTPException(409, 'ERP work packet changed; refresh before invocation')
        args = dict(
            invocation_id=body.invocation_id,
            project=project_id,
            task=body.erp_task_id,
            from_role=body.from_role,
            target_role=body.target_role,
            task_revision=packet['task_revision'],
            context=body.context,
            work_packet=packet,
            gate=gate,
            actor='authenticated-erp-bridge',
        )
        if body.from_role != 'erp':
            source = ledger.find(body.source_invocation_id or '', include_private=True)
            from open_webui.utils.agentic_result_store import get_result

            published = get_result(body.source_invocation_id or '')
            if (
                not source
                or source['erp_project'] != project_id
                or source['target_role'] != body.from_role
                or source['agent_id'] != body.from_agent_id
                or source['state'] != 'execution_finished'
                or not published
                or published['phase'] != 'published'
                or published['run_id'] != source['automation_run_id']
            ):
                raise HTTPException(403, 'An authenticated finished source invocation is required')
            if source['erp_task'] == body.erp_task_id:
                row, created = ledger.handoff(
                    **args,
                    source_invocation_id=source['invocation_id'],
                    source_run_id=source['automation_run_id'],
                    source_lease_token=source['lease_token'],
                )
            else:
                child = await bridge.erp.get('Task', body.erp_task_id)
                if (
                    child.get('project') != project_id
                    or child.get('parent_task') != source['erp_task']
                    or child.get('custom_agov_source_run') != source['automation_run_id']
                    or not child.get('custom_agov_dispatch_released')
                ):
                    raise HTTPException(403, 'Agent fanout requires a verified child task in the same ERP project')
                row, created = ledger.enqueue(**args, parent_invocation_id=source['invocation_id'])
        else:
            row, created = ledger.enqueue(**args)
    except ValueError as error:
        raise HTTPException(409, str(error)) from None
    finally:
        await bridge.close()
    if created:
        _spawn(request.app, _deliver(request.app, body.invocation_id))
    return {
        'invocation_id': body.invocation_id,
        'state': row['state'],
        'created': created,
        'project': project_id,
        'target_role': body.target_role,
    }


@router.get("/projects/{project_id}/invocations", response_model=InvocationHistoryResponse)
async def invocations(project_id: str, control_secret: str = Header(default="", alias="X-ABIT-ERP-Control")):
    _auth(control_secret)
    # Never echo prompt/context, secrets or ERP private work packet contents.
    return {"project": project_id, "runs": list_invocations(project_id)}


def _reconciliation_wakeup(app):
    wakeup = getattr(app.state, 'agentic_reconciliation_wakeup', None)
    if wakeup is None:
        wakeup = asyncio.Event()
        app.state.agentic_reconciliation_wakeup = wakeup
    return wakeup


async def _recover_due_original(app):
    """Yield one existing maintenance boundary to the oldest due original."""
    from open_webui.utils.agentic_recovery_telemetry import due_recoveries

    try:
        due = due_recoveries(limit=1)
        if due:
            row = due[0]
            # This exact filter prevents recursion and historical-row scans.
            # No new task, timer, development submission or authority is created here.
            await _recover_project(app, row['erp_project'],
                                   due_invocation_id=row['invocation_id'])
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception('Due original retained its existing recovery gate')


async def reconciliation_loop(app):
    """ONE global fallback; authenticated channel-ready edges wake this same loop."""
    from open_webui.utils import agentic_governance as ledger
    from open_webui.utils.agentic_bridge import ERPBridge, RPC
    from open_webui.utils.agentic_orchestrator import scan_project

    wakeup = _reconciliation_wakeup(app)
    while True:
        wakeup.clear()
        try:
            cfg = _config()
            bridge = ERPBridge(cfg)
            try:
                await bridge.erp.request(
                    'POST', RPC + 'recover_outbox', json={}, headers={'X-ABIT-Agentic-Bridge': bridge.secret}
                )
            except Exception:
                log.exception('ERP outbox recovery unavailable; original events retained')
            finally:
                await bridge.close()
            await _recover_due_original(app)
            result = ledger.recoverable()
            for ident in result['queued_for_reconciliation']:
                _spawn(app, _deliver(app, ident))
            for event in ledger.pending_events():
                try:
                    await _recover_due_original(app)
                    await _process_event(app, event['event_id'], event['payload'], maintenance_priority=True)
                except Exception:
                    log.exception('Governance event remains durably pending: %s', event['event_id'])
            with ledger.connect() as db:
                projects = [
                    r[0] for r in db.execute('SELECT DISTINCT erp_project FROM governance_agent ORDER BY erp_project')
                ]

            async def dispatch(ident):
                _spawn(app, _deliver(app, ident))

            for project in projects:
                await _recover_due_original(app)
                await _recover_project(app, project, maintenance_priority=True)
                try:
                    await _recover_due_original(app)
                    await scan_project(project, config=cfg, project_gate=_gate, dispatch=dispatch)
                except Exception:
                    log.exception('Governance reconciliation preserved project %s', project)
        except asyncio.CancelledError:
            for task in list(getattr(app.state, 'agentic_execution_tasks', set())):
                task.cancel()
            await asyncio.gather(*getattr(app.state, 'agentic_execution_tasks', set()), return_exceptions=True)
            raise
        except Exception:
            log.exception('Governance recovery preserved existing requests')
        # The same one loop handles due retry backoff and the long fallback.
        # A new deferral or authenticated channel-ready edge coalesces a wake.
        delay = RECONCILE_SECONDS
        try:
            from open_webui.utils.agentic_preclaim_recovery import next_wakeup_delay
            delay = next_wakeup_delay(RECONCILE_SECONDS)
        except Exception:
            log.exception('Preclaim due-time reader unavailable; retained ordinary fallback')
        try:
            from open_webui.utils.agentic_recovery_telemetry import next_wakeup_delay as original_delay
            delay = original_delay(delay)
        except Exception:
            log.exception('Original recovery due-time reader unavailable; retained existing wait')
        try:
            await asyncio.wait_for(wakeup.wait(), delay)
        except asyncio.TimeoutError:
            pass


class ProjectControlInput(BaseModel):
    """Signed ERP controls; Retry may request one fresh atomic PM review after an operator-verified repository prerequisite repair. Published results remain immutable."""
    model_config = ConfigDict(extra='forbid')
    action: Literal['start', 'pause', 'resume', 'stop', 'retry']
    command_id: str = Field(min_length=12, max_length=160, pattern=r'^[A-Za-z0-9_.:@+-]+$')
    control_sequence: int = Field(strict=True, ge=1, description='Exact existing human ERP native control intent sequence; never created by this route.')
    expected_revision: str = Field(min_length=1, max_length=100)
    actor: str = Field(min_length=1, max_length=254)
    task_id: str | None = Field(default=None, pattern=r'^TASK-[A-Za-z0-9-]{1,60}$')
    target_role: Literal['solution_architect', 'project_manager'] = 'project_manager'


class ERPEventInput(BaseModel):
    model_config = ConfigDict(extra='forbid')
    schema_version: Literal[1]
    event_id: str = Field(min_length=12, max_length=160, pattern=r'^[A-Za-z0-9_.:@+-]+$')
    type: Literal['project.changed', 'project.control', 'task.ready', 'backlog.ready', 'result.recorded']
    project: str = Field(pattern=r'^PROJ-[A-Za-z0-9-]{1,60}$')
    task: str = Field(default='', max_length=70)
    revision: str = Field(min_length=1, max_length=100)
    payload: dict = Field(default_factory=dict, max_length=50)
    source_modified: str = Field(min_length=1, max_length=100)


class EventReceipt(BaseModel):
    event_id: str
    durable: bool
    duplicate: bool = False


class ProjectStatusResponse(BaseModel):
    project: str
    control: dict
    agents: list[dict]
    task_controls: list[dict]
    invocations: list[dict]
    audit: list[dict]
    execution_semantics: str


class CommandReceipt(BaseModel):
    project: str
    command_id: str
    durable: bool
    state: str


async def _process_event(app, event_id, event, *, maintenance_priority=False):
    from open_webui.utils.agentic_events import process_event
    from open_webui.utils.agentic_bridge import ERPBridge
    from open_webui.utils.agentic_orchestrator import scan_project

    cfg = _config()

    async def dispatch(ident):
        _spawn(app, _deliver(app, ident))

    async def scan(project):
        if maintenance_priority:
            await _recover_due_original(app)
        return await scan_project(project, config=cfg, project_gate=_gate, dispatch=dispatch)

    async def recover(project, task, explicit):
        options={'explicit':explicit}
        if maintenance_priority:
            options['maintenance_priority'] = True
        if (explicit and task and event.get('type') == 'project.control'
            and (event.get('payload') or {}).get('action') == 'retry'):
            options['retry_event_id']=event_id
        return await _recover_project(app, project, task, **options)

    return await process_event(
        event_id,
        event,
        config=cfg,
        project_gate=_gate,
        provision=_provision_project,
        bridge_factory=ERPBridge,
        dispatch=dispatch,
        scan=scan,
        recover=recover,
    )


async def _recover_project(app, project, task=None, *, explicit=False, retry_event_id=None,
                           due_invocation_id=None, maintenance_priority=False):
    from open_webui.utils import agentic_governance as ledger
    from open_webui.utils.agentic_bridge import ERPBridge
    from open_webui.utils.agentic_result_store import get_result
    from open_webui.utils.agentic_executor import reconcile_publication
    from open_webui.utils.agentic_recovery import recover_original, resume_qa_preflight
    from open_webui.utils.agentic_it_execution import resume, recover_completed
    from open_webui.utils.agentic_unsubmitted import rearm
    from open_webui.utils.agentic_controls import task_control
    from open_webui.utils.agentic_recovery_telemetry import run_recovery

    cfg = _config()
    bridge = ERPBridge(cfg)
    reconciled = []
    try:
        for public in ledger.list_invocations(project, limit=100):
            if due_invocation_id and public['invocation_id'] != due_invocation_id:
                continue
            if maintenance_priority:
                await _recover_due_original(app)
            if task and public['erp_task'] != task:
                continue
            row = ledger.find(public['invocation_id'], include_private=True)
            ident = row['invocation_id']
            receipt = None
            try:
                if explicit and task and retry_event_id and row['state'] in {'uncertain','failed'} and row['target_role'] != 'it_manager':
                    from open_webui.utils.agentic_transport_retry import retry_rejected_transport
                    from open_webui.utils.agentic_executor import DotAdapter
                    from open_webui.models.automations import Automations

                    automation = await Automations.get_by_id(row['agent_id'])
                    new_id = await retry_rejected_transport(ident,retry_event_id,automation=automation,
                        adapter=DotAdapter(app),bridge=bridge,project_gate=_gate,config=cfg)
                    if new_id:
                        retry_row=ledger.find(new_id)
                        if retry_row and retry_row['state']=='queued':
                            _spawn(app,_deliver(app,new_id))
                        reconciled.append(new_id)
                        continue
                if (explicit and task and retry_event_id and row['target_role']=='developer'
                        and row.get('reason')=='ValueError: Infrastructure templates cannot carry credentials, authority fields, commands or URLs'):
                    from open_webui.utils.agentic_prerequisite_retry import resume_completed_protocol_rejection
                    corrected=await resume_completed_protocol_rejection(ident,retry_event_id,
                        config=cfg,bridge=bridge,project_gate=_gate)
                    if corrected:
                        candidate=ledger.find(corrected)
                        if candidate and candidate['state']=='queued':
                            _spawn(app,_deliver(app,corrected))
                        reconciled.append(corrected)
                        continue
                saved = get_result(ident)
                if saved:
                    if (explicit and task and retry_event_id and row['target_role'] == 'project_manager'
                            and row['state'] == 'execution_finished' and saved['phase'] == 'published'
                            and saved['result'].get('outcome') == 'blocked'):
                        from open_webui.utils.agentic_prerequisite_retry import resume_registered_repository
                        next_id = await resume_registered_repository(ident,retry_event_id,config=cfg,
                            bridge=bridge,project_gate=_gate)
                        if next_id:
                            new_row=ledger.find(next_id)
                            if new_row and new_row['state']=='queued':
                                _spawn(app,_deliver(app,next_id))
                            reconciled.append(next_id)
                            continue
                    if (explicit and row['target_role'] == 'qa' and row['state'] == 'execution_finished'
                            and saved['phase'] == 'published' and saved['result'].get('outcome') == 'blocked'):
                        continued = await resume_qa_preflight(ident, bridge=bridge, project_gate=_gate, config=cfg)
                        if continued:
                            successor, created = continued
                            if created:
                                _spawn(app, _deliver(app, successor['invocation_id']))
                            reconciled.append(ident)
                            continue
                    if saved['phase'] == 'pending':
                        if row['state'] not in {'running', 'uncertain', 'execution_finished'}:
                            continue
                        if (
                            ledger.project_control(project)['state'] != 'enabled'
                            or task_control(project, row['erp_task'])['state'] != 'enabled'
                        ):
                            continue
                        if row['target_role'] == 'it_manager' or row['submitted_at'] is None:
                            await _gate(project, cfg)

                    async def guarded_publication():
                        # Submitted pending-result gate reads belong to their
                        # existing audited attempt, including timeout/backoff.
                        if saved['phase'] == 'pending':
                            await _gate(project, cfg)
                        return await reconcile_publication(ident, bridge)
                    # A confirmed publication must still reach the existing
                    # idempotent handoff after an earlier handoff failure.
                    if (row['state'] in {'running', 'uncertain'} and row['submitted_at'] is not None
                            and row['target_role'] != 'it_manager'):
                        # save_result commits before finish_execution. Restore only
                        # that exact original transition through bounded, audited
                        # recovery before an existing receipt can hand off.
                        receipt = await run_recovery(
                            ident, lambda: recover_original(
                                ident, config=cfg, project_gate=_gate, bridge=bridge, app=app,
                            ), stage='original_reconciliation', config=cfg,
                            notify=_reconciliation_wakeup(app).set,
                        )
                    elif (saved['phase'] == 'published' or row['target_role'] == 'it_manager'
                            or row['submitted_at'] is None):
                        receipt = await reconcile_publication(ident, bridge)
                    else:
                        receipt = await run_recovery(
                            ident, guarded_publication,
                            stage='publication_reconciliation', config=cfg,
                            notify=_reconciliation_wakeup(app).set,
                        )
                elif row['state'] == 'awaiting_approval':
                    from open_webui.utils.agentic_native_verification import selected_packet
                    approval_resume = resume
                    if row['target_role'] == 'it_manager' and selected_packet(json.loads(row['work_packet'])):
                        from open_webui.utils.agentic_native_execution import resume as approval_resume
                    receipt = await approval_resume(ident, config=cfg, project_gate=_gate, bridge=bridge, app=app)
                elif row['state'] in {'uncertain', 'cancel_requested'}:
                    recovery = recover_completed if row['target_role'] == 'it_manager' else recover_original
                    if row['target_role'] == 'it_manager':
                        from open_webui.utils.agentic_native_verification import selected_packet
                        if selected_packet(json.loads(row['work_packet'])):
                            from open_webui.utils.agentic_native_execution import recover_completed as recovery
                    if row['target_role'] == 'it_manager' or row['submitted_at'] is None:
                        # Preserve the independently guarded IT/unsubmitted paths.
                        receipt = await recovery(ident, config=cfg, project_gate=_gate, bridge=bridge, app=app)
                    else:
                        receipt = await run_recovery(
                            ident, lambda: recovery(ident, config=cfg, project_gate=_gate, bridge=bridge, app=app),
                            stage='original_reconciliation', config=cfg,
                            notify=_reconciliation_wakeup(app).set,
                        )
                elif (row['state'] == 'queued' and not row['automation_run_id']
                      and row['submitted_at'] is None):
                    # A prior event may have queued this exact successor while
                    # admission was closed. Wake it; never create or rearm it.
                    await _gate(project, cfg)
                    if (ledger.project_control(project)['state'] == 'enabled'
                            and task_control(project, row['erp_task'])['state'] == 'enabled'):
                        _spawn(app, _deliver(app, ident))
                        reconciled.append(ident)
                elif explicit and row['state'] == 'blocked' and not row['automation_run_id']:
                    _, gate = await _gate(project, cfg)
                    packet = await bridge.packet(project, row['erp_task'], row['target_role'], row['agent_id'])
                    rearm(ident, packet, gate, 'authenticated-erp-retry')
                    _spawn(app, _deliver(app, ident))
                    reconciled.append(ident)
                if receipt:
                    reconciled.append(ident)
                    await _gate(project, cfg)
                    if ledger.project_control(project)['state'] == 'enabled':
                        await _advance(app, ident, receipt)
            except Exception:
                log.exception('Original governance recovery retained its fence: %s', ident)
    finally:
        await bridge.close()
    return reconciled


@router.post('/events', response_model=EventReceipt, status_code=202)
async def receive_erp_event(body: ERPEventInput, request: Request):
    """Accept an HMAC-authenticated ERP outbox event once, before execution.

    Enabled projects automatically select eligible idle tasks through the native
    ERP pickup API. Existing signed Start events retain their original identity.
    Execution is queued by project: one task advances through developer,
    independent QA and PM review before the next task starts. Dependency and
    hierarchy gates, human ownership, Pause/Stop and uncertainty remain enforced.

    Requires a timestamp within five minutes and exact signed event identity.
    Duplicate content returns the existing durable inbox receipt. Changed content
    under one ID is rejected. Model execution occurs asynchronously and is never
    implied by HTTP acceptance. No shared credential is returned to the browser.
    An explicit Native Task Retry may create one fresh execution generation only
    after exact positive transport-rejection proof, zero original gateway work,
    and Native acknowledgement clearing that same failed outgoing active run.
    A verified blocker-triage PM rejection before gateway admission preserves
    the Blocked status and restores the published blocker as the retry source.
    """
    from open_webui.utils.agentic_bridge import bridge_secret, verify_event
    from open_webui.utils.agentic_governance import receive_event

    event = body.model_dump()
    try:
        verify_event(event, dict(request.headers), bridge_secret(_config()))
        row, created = receive_event(body.event_id, body.project, event, actor='signed-erp')
    except ValueError as error:
        raise HTTPException(409, str(error)) from None
    if created:
        _spawn(request.app, _process_event(request.app, body.event_id, event))
    return EventReceipt(event_id=body.event_id, durable=True, duplicate=not created)


@router.get('/projects/{project_id}/status', response_model=ProjectStatusResponse)
async def project_status(project_id: str, control_secret: str = Header(default='', alias='X-ABIT-ERP-Control')):
    """ERP-only project controls, role registry, bounded run history and audit.

    Read access remains available after opt-out, Hold or Stop. Private prompts,
    packets, lease tokens and connector credentials are never included. A finished
    model execution is distinct from verified independent QA and ERP readback.

    Each existing invocation may include delivery_diagnostics: bounded original
    provider observations, gateway operation counts, publication presence and
    integrity-verified packet/context hashes. The optional original_observation
    is null or {code, checked_at}: a fixed diagnostic code from the last scoped,
    authenticated original read and its Core UTC timestamp (epoch seconds).
    The optional recovery object separately reports the original recovery stage,
    last meaningful progress, recovery attempt and earliest permitted retry.
    A status read does not advance progress or submit work. Unknown clocks and
    unrecorded attempts remain unavailable rather than inferred from Working.

    This metadata grants no completion, recovery or retry authority and never
    replaces a provider receipt. Unavailable optional diagnostics
    do not change the existing status fields or their failure semantics.
    """
    _auth(control_secret)
    if not PROJECT_ID.fullmatch(project_id):
        raise HTTPException(400, 'Invalid ERP Project ID')
    from open_webui.utils import agentic_governance as ledger
    from open_webui.utils.agentic_controls import task_controls
    from open_webui.utils.agentic_events import effective_control

    status = {
        'project': project_id,
        'control': effective_control(project_id),
        'task_controls': task_controls(project_id),
        'agents': [{k: v for k, v in r.items() if k != 'owner_id'} for r in roster(project_id)],
        'invocations': list_invocations(project_id, limit=100),
        'audit': ledger.audit_events(project_id),
        'execution_semantics': 'Queued -> Running -> execution_finished -> independent QA + ERP -> verified. Unknown upstream work remains fenced.',
    }

    # Preserve the existing authenticated status contract. Optional service-owned
    # observations must never change execution state or suppress normal status.
    try:
        from open_webui.utils.agentic_execution_diagnostics import enrich_status_invocations
        status['invocations'] = await asyncio.to_thread(
            enrich_status_invocations, project_id, status['invocations']
        )
    except Exception:
        # No exception text, provider reply, prompt or authority is exposed.
        status['invocations'] = [
            {**row, 'delivery_diagnostics': {
                'schema_version': 1, 'read_only': True, 'available': False,
                'error_code': 'DIAGNOSTIC_READER_UNAVAILABLE',
                'semantics': 'Original-run journal observations only; not a completion, recovery or retry authorization.',
            }}
            if 'delivery_diagnostics' not in row else row
            for row in status['invocations']
        ]
    return status


@router.post('/projects/{project_id}/control', response_model=CommandReceipt, status_code=202)
async def control_project(
    project_id: str,
    body: ProjectControlInput,
    request: Request,
    control_secret: str = Header(default='', alias='X-ABIT-ERP-Control'),
):
    """Idempotent ERP control: Start/Pause/Resume/Stop or reconcile original results.

    Mirror an existing human ERP control intent using its exact sequence, command,
    actor and Task scope. Legacy requests without control_sequence fail validation;
    mismatched or superseded native intents fail before durable inbox mutation.
    Create controls in ERP; this route never creates an intent or substitutes actors.

    Start/Resume require the current opt-in checkbox, active Project and matching
    open ai-projects assignment. Pause/Stop remain available after revocation.
    Active Stop means cancellation requested until an upstream receipt confirms
    termination; Retry never blindly reruns an unknown/submitted model request.
    """
    _auth(control_secret)
    from open_webui.utils.agentic_governance import receive_event

    if not PROJECT_ID.fullmatch(project_id):
        raise HTTPException(400, 'Invalid ERP Project ID')
    cfg = _config()
    if body.action not in {'pause', 'stop'}:
        project = await _erp_project(project_id, cfg)
    else:
        from open_webui.utils.agentic_erp_runtime import governed_client as ERPClient

        erp = ERPClient(cfg['erp_token_file'])
        try:
            project = await erp.get('Project', project_id)
        finally:
            await erp.client.aclose()
    if str(project['modified']) != body.expected_revision:
        raise HTTPException(409, 'ERP Project revision changed')
    if body.task_id:
        from open_webui.utils.agentic_erp_runtime import governed_client as ERPClient

        erp = ERPClient(cfg['erp_token_file'])
        try:
            task = await erp.get('Task', body.task_id)
        finally:
            await erp.client.aclose()
        if task.get('project') != project_id:
            raise HTTPException(403, 'Task belongs to another ERP Project')
    event = {
        'schema_version': 1,
        'event_id': body.command_id,
        'type': 'project.control',
        'project': project_id,
        'task': body.task_id or '',
        'revision': body.expected_revision,
        'source_modified': body.expected_revision,
        'payload': {**body.model_dump(), 'task_id': body.task_id or ''},
    }
    # Read the server-owned human intent before recording a durable Core command.
    # The normal processor rechecks this same binding before applying or acknowledging it.
    from open_webui.utils.agentic_bridge import ERPBridge

    bridge = ERPBridge(cfg)
    try:
        response = await bridge.erp.request(
            'GET', '/api/method/abit_ai_assistant.agentic_control_fence.get_control_intent',
            params={'project_id': project_id, 'task_id': event['task']},
            headers={'X-ABIT-Agentic-Bridge': bridge.secret},
        )
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(503, _erp_failure(error, 'Native control intent readback unavailable; no Core command recorded')) from None
    finally:
        await bridge.close()
    current = response.get('message') if isinstance(response, dict) else None
    intent = current.get('intent') if isinstance(current, dict) else None
    expected = {
        'project_id': project_id, 'task_id': event['task'],
        'command_id': body.command_id, 'control_sequence': body.control_sequence,
        'action': body.action, 'actor': body.actor,
    }
    if (not isinstance(current, dict) or current.get('project_id') != project_id
            or current.get('task_id') != event['task'] or not isinstance(intent, dict)
            or any(type(intent.get(key)) is not type(value) or intent[key] != value
                   for key, value in expected.items())):
        raise HTTPException(409, 'Exact current human ERP control intent required')
    try:
        row, created = receive_event(body.command_id, project_id, event, actor=body.actor)
    except ValueError as error:
        raise HTTPException(409, str(error)) from None
    if created:
        _spawn(request.app, _process_event(request.app, body.command_id, event))
    return {'project': project_id, 'command_id': body.command_id, 'durable': True, 'state': row['state']}


class NativeVerificationReceipt(BaseModel):
    model_config = ConfigDict(extra="forbid")
    schema_version: Literal[1]
    state: Literal["uncertain", "running", "completed", "failed_retained"]
    binding_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    gate_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    nonce: str = Field(pattern=r"^[a-f0-9]{32}$")
    authority_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    execution_manifest_sha256: str = Field(pattern=r"^[a-f0-9]{64}$")
    worker_head: str = Field(pattern=r"^[a-f0-9]{40}$")
    outcome_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    worker_result_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    reservation_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    cleanup_confirmed: bool
    operations_count: Literal[0, 10]
    automatic_replay_permitted: Literal[False]
    authority_issued: Literal[False]


class NativeVerificationStatus(BaseModel):
    model_config = ConfigDict(extra="forbid")
    invocation_id: str
    available: bool
    phase: Literal["bound", "launch_unknown", "uncertain", "running", "completed", "failed_retained"] | None
    binding_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    gate_sha256: str | None = Field(default=None, pattern=r"^[a-f0-9]{64}$")
    receipt: NativeVerificationReceipt | None = None
    automatic_replay_permitted: Literal[False]
    independent_qa_approved: Literal[False]


@router.get("/projects/{project_id}/native-verification/{invocation_id}",
            response_model=NativeVerificationStatus, tags=["Agentic native verification"])
async def native_verification_status(project_id: str, invocation_id: str,
        control_secret: str = Header(default="", alias="X-ABIT-ERP-Control")):
    """Read bounded original native verification metadata under ERP control auth.

    Execution is only the explicit verify_native_source IT WorkPacket operation,
    in a registered native-verification environment, with current human ERP
    approval consumed once and an independently issued root gate/v4 authority.
    This GET never dispatches, reconciles, issues authority or changes a Task.
    A completed fixed plan is evidence for independent QA, not business approval.
    Original launch uncertainty never permits a repeat.
    """
    _auth(control_secret)
    if not PROJECT_ID.fullmatch(project_id) or not invocation_id or len(invocation_id) > 160:
        raise HTTPException(400, "Invalid native verification identity")
    row = find(invocation_id)
    if not row or row["erp_project"] != project_id:
        raise HTTPException(404, "Original governed invocation not found")
    from open_webui.utils.agentic_native_verification import public_status
    try:
        return public_status(invocation_id)
    except (ValueError, TypeError, KeyError):
        raise HTTPException(409, "Original native evidence integrity requires review") from None
