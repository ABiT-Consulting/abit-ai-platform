"""A technical preflight failure is retryable only with proof no work was sent."""

import time
import json
from open_webui.utils import agentic_governance as ledger


def block(invocation, reason, db_path=None):
    with ledger._transaction(db_path) as db:
        row = db.execute('SELECT * FROM governance_invocation WHERE invocation_id=?', (invocation,)).fetchone()
        if not row or row['state'] != 'queued' or row['submitted_at'] is not None or row['automation_run_id']:
            return False
        db.execute(
            "UPDATE governance_invocation SET state='blocked',reason=?,updated_at=? WHERE invocation_id=?",
            (str(reason)[:500], int(time.time()), invocation),
        )
        ledger._release(db, row)
        ledger._event(
            db,
            row['erp_project'],
            invocation,
            'unsubmitted_preflight_blocked',
            'executor',
            {'reason': str(reason)[:500]},
        )
        return True



def preserve_planning_packet(row, fresh):
    """Retain an unused original when only informational backlog status changed.

    This does not refresh or replace a packet. Task/source revision, planning
    context, ownership and every other business field remain exactly frozen.
    The caller still performs the existing claim-history and authorization gates.
    """
    from open_webui.utils.agentic_bridge import packet_digest, same_business_context

    row = dict(row)
    if (row.get('state') not in {'queued', 'blocked'}
            or row.get('target_role') not in {'project_manager', 'solution_architect'}
            or row.get('submitted_at') is not None or row.get('automation_run_id')
            or row.get('dispatch_attempts') != 0):
        raise ValueError('Only never-claimed planning packets permit informational backlog equivalence')
    try:
        original = json.loads(row['work_packet'])
    except (KeyError, TypeError, ValueError):
        raise ValueError('Original planning packet is unavailable') from None
    if (ledger.work_packet_digest(original) != row.get('packet_hash')
            or original.get('content_sha256') != packet_digest(original)
            or fresh.get('content_sha256') != packet_digest(fresh)):
        raise ValueError('Original or current planning packet integrity differs')
    identity = {'project_id':row.get('erp_project'), 'task_id':row.get('erp_task'),
                'task_revision':row.get('task_revision')}
    binding = original.get('binding') or {}
    if (any(original.get(k) != v for k,v in identity.items())
            or binding.get('role') != row['target_role']
            or binding.get('agent_id') != row.get('agent_id')
            or original.get('qa_review') or fresh.get('qa_review')
            or not same_business_context(original, fresh, {'packet_id', 'content_sha256'})):
        raise ValueError('Planning business context changed; original packet remains blocked')
    before, after = original.get('project_backlog'), fresh.get('project_backlog')
    if not isinstance(before, dict) or not isinstance(after, dict):
        raise ValueError('Complete frozen planning backlog is required')
    # PM/architecture context equality is already required by same_business_context.
    # Narrow it further: only existing rows' status/source_modified can differ.
    # Other informational fields (priority, assignees, due dates, exclusions) stay exact.
    def fixed(backlog):
        rows = backlog.get('tasks')
        if not isinstance(rows, list) or any(not isinstance(item, dict) for item in rows):
            raise ValueError('Complete frozen planning backlog is required')
        expected = ledger._digest({'project_id':backlog.get('project_id'), 'tasks':rows})
        if backlog.get('snapshot_sha256') != expected:
            raise ValueError('Planning backlog snapshot integrity differs')
        return {
            **{k:v for k,v in backlog.items() if k not in {'snapshot_sha256', 'tasks'}},
            'tasks':[{k:v for k,v in item.items() if k not in {'status', 'source_modified'}}
                     for item in rows],
        }
    if fixed(before) != fixed(after):
        raise ValueError('Planning backlog changed beyond informational execution status')
    return original


def rearm(invocation, packet, gate, actor, db_path=None):
    with ledger._transaction(db_path) as db:
        row = db.execute('SELECT * FROM governance_invocation WHERE invocation_id=?', (invocation,)).fetchone()
        if (
            not row
            or row['state'] != 'blocked'
            or row['submitted_at'] is not None
            or row['automation_run_id']
        ):
            raise ValueError('Retry requires the unchanged original packet and proof it was never submitted')
        if row['packet_hash'] != ledger.work_packet_digest(packet):
            # The immutable stored packet and its hash are never updated.
            preserve_planning_packet(row, packet)
        ledger._gate(db, row['erp_project'], gate)
        ledger._task_gate(db, row['erp_project'], row['erp_task'])
        retries = db.execute(
            "SELECT COUNT(*) FROM governance_event WHERE invocation_id=? AND kind='original_unsubmitted_rearmed'",
            (invocation,),
        ).fetchone()[0]
        claimed = db.execute(
            "SELECT 1 FROM governance_event WHERE invocation_id=? AND kind='execution_claimed' LIMIT 1",
            (invocation,),
        ).fetchone()
        if claimed or row['dispatch_attempts'] not in {0, retries}:
            raise ValueError('Original preflight history does not prove it was never claimed')
        if retries >= 3:
            raise ValueError('Original preflight retry limit reached')
        fence = ledger._acquire(db, row['erp_project'], row['erp_task'], invocation)
        db.execute(
            "UPDATE governance_invocation SET state='queued',lease_fence=?,reason=NULL,dispatch_attempts=0,updated_at=? WHERE invocation_id=?",
            (fence, int(time.time()), invocation),
        )
        ledger._event(db, row['erp_project'], invocation, 'original_unsubmitted_rearmed', actor,
                      {'fence': fence, 'preflight_attempt': retries + 1,
                       'previous_dispatch_attempts': row['dispatch_attempts'], 'dispatch_attempts': 0})
    return ledger.find(invocation, db_path)
